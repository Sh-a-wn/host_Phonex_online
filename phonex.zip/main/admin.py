from django.contrib import admin
from .models import Brands, Make

# Register your models here.
admin.site.register(Brands)
admin.site.register(Make)
